const TARGET_WORDS = ["Elon Musk", "Elon"];
const REPLACEMENT_WORD = "The Antichrist";
const EXPLICIT_REPLACEMENTS = [
  { pattern: "Musk's", replacement: "Antichrist's" },
  { pattern: "Musk", replacement: "Antichrist" },
];

const SKIP_TAGS = new Set([
  "SCRIPT",
  "STYLE",
  "TEXTAREA",
  "INPUT",
  "NOSCRIPT",
]);

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const WORD_REGEX = new RegExp(
  TARGET_WORDS
    .slice()
    .sort((a, b) => b.length - a.length)
    .map((word) => `\\b${escapeRegExp(word)}\\b`)
    .join("|"),
  "g"
);

const EXPLICIT_REGEXES = EXPLICIT_REPLACEMENTS.map(({ pattern, replacement }) => ({
  regex: new RegExp(`\\b${escapeRegExp(pattern)}\\b`, "g"),
  replacement,
}));

function shouldSkipNode(node) {
  const parent = node.parentNode;
  if (!parent || parent.nodeType !== Node.ELEMENT_NODE) {
    return true;
  }
  return SKIP_TAGS.has(parent.nodeName);
}

function hasMatch(text) {
  WORD_REGEX.lastIndex = 0;
  return WORD_REGEX.test(text);
}

function replaceInTextNode(node) {
  if (!node.nodeValue) {
    return;
  }
  let updated = node.nodeValue;
  WORD_REGEX.lastIndex = 0;
  updated = updated.replace(WORD_REGEX, REPLACEMENT_WORD);
  for (const { regex, replacement } of EXPLICIT_REGEXES) {
    regex.lastIndex = 0;
    updated = updated.replace(regex, replacement);
  }
  if (updated !== node.nodeValue) {
    node.nodeValue = updated;
  }
}

function scanAndReplace(root) {
  if (!root) {
    return;
  }
  const walker = document.createTreeWalker(
    root,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        if (shouldSkipNode(node)) {
          return NodeFilter.FILTER_REJECT;
        }
        return hasMatch(node.nodeValue)
          ? NodeFilter.FILTER_ACCEPT
          : NodeFilter.FILTER_REJECT;
      },
    }
  );

  const nodes = [];
  while (walker.nextNode()) {
    nodes.push(walker.currentNode);
  }

  for (const node of nodes) {
    replaceInTextNode(node);
  }
}

function observeChanges() {
  if (!document.body) {
    return;
  }
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === Node.TEXT_NODE) {
          if (!shouldSkipNode(node)) {
            replaceInTextNode(node);
          }
        } else if (node.nodeType === Node.ELEMENT_NODE) {
          scanAndReplace(node);
        }
      }
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

scanAndReplace(document.body);
observeChanges();
